-- Dùng database demo theo đề bài. Các bảng liên quan transaction cần dùng InnoDB.
CREATE DATABASE IF NOT EXISTS demo CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE demo;

CREATE TABLE IF NOT EXISTS users (
  id INT NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  country VARCHAR(100) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permission (
  id INT NOT NULL,
  name VARCHAR(50) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permission_name (name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_permission (
  user_id INT NOT NULL,
  permission_id INT NOT NULL,
  PRIMARY KEY (user_id, permission_id),
  CONSTRAINT fk_user_permission_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_user_permission_permission FOREIGN KEY (permission_id) REFERENCES permission(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

INSERT INTO permission (id, name) VALUES
  (1, 'add'), (2, 'edit'), (3, 'delete'), (4, 'view')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Tùy chọn: thêm dữ liệu mẫu nếu bảng users đang trống.
INSERT INTO users (name, email, country)
SELECT 'An Nguyen', 'an@example.com', 'Vietnam'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'an@example.com');
INSERT INTO users (name, email, country)
SELECT 'Binh Tran', 'binh@example.com', 'Vietnam'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'binh@example.com');
INSERT INTO users (name, email, country)
SELECT 'Charlotte Martin', 'charlotte@example.com', 'France'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email = 'charlotte@example.com');

-- Kiểm tra sau khi thêm user qua form.
-- SELECT * FROM users ORDER BY id DESC LIMIT 1;
-- SELECT up.user_id, p.id AS permission_id, p.name
-- FROM user_permission up JOIN permission p ON p.id = up.permission_id
-- ORDER BY up.user_id DESC, p.id;

-- Bảng Employee dùng riêng cho bài thực hành transaction.
-- DAO sẽ DROP/CREATE lại bảng này mỗi lần chạy action=test-use-tran.
CREATE TABLE IF NOT EXISTS Employee (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  salary DECIMAL(10,2) NOT NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB;
