# User Management: JDBC Transaction

Bài mẫu JSP/Servlet/JDBC/MySQL chạy với Java 17 và Tomcat 10.1+. Project có chức năng tìm User theo country, sắp xếp theo name và thêm User cùng nhiều quyền trong một transaction.

## Cài đặt và chạy
1. Mở `database.sql` trong MySQL Workbench và chạy. Nếu đã có database `demo` cùng bảng `users`, kiểm tra bảng đó có các cột `id` (AUTO_INCREMENT), `name`, `email`, `country`, và dùng InnoDB. Script tạo thêm `permission`, `user_permission` và dữ liệu quyền.
2. Trong `src/main/webapp/WEB-INF/web.xml`, sửa `jdbcUsername` và `jdbcPassword` theo MySQL của bạn.
3. Cài Maven và JDK 17, tại thư mục project chạy `mvn clean package`.
4. Copy `target/user-management-search-sort.war` vào `webapps` của Tomcat 10.1+ rồi khởi động Tomcat.
5. Truy cập `http://localhost:8080/user-management-search-sort/users`; chọn **Thêm người dùng**, điền thông tin và chọn các quyền.

## Phần transaction
`UserDAO.addUserTransaction()` tắt auto-commit, thêm User và lấy ID sinh tự động, thêm các dòng `user_permission`, rồi commit. Nếu một thao tác SQL lỗi, DAO rollback và ném lỗi lên Servlet; không nuốt lỗi. Cả ba bảng dùng InnoDB để MySQL hỗ trợ rollback.

## Kiểm tra
Chạy sau khi gửi form thành công:
```sql
SELECT * FROM users ORDER BY id DESC LIMIT 1;
SELECT up.user_id, p.id, p.name
FROM user_permission up JOIN permission p ON p.id = up.permission_id
ORDER BY up.user_id DESC, p.id;
```
Để thử rollback, tạm thời chọn permission ID không tồn tại trong `UserServlet` hoặc tắt FK trong script kiểm thử có chủ đích; sau lỗi, dòng User mới cũng không được giữ lại.

## Thực hành Employee transaction
- Rollback cố tình tạo lỗi: `http://localhost:8080/user-management-search-sort/users?action=test-use-tran&mode=fail` — trang kết quả phải báo lỗi và bảng Employee trống.
- Commit thành công: `http://localhost:8080/user-management-search-sort/users?action=test-use-tran&mode=success` — có Quynh (999.99) và Ngan (20.00).
- Mỗi lần chạy bài test, DAO DROP rồi CREATE lại bảng `Employee` trước transaction để kết quả dễ đối chiếu. Chỉ dùng chức năng này với database thực hành.

## Bài tập: Luyện tập MySQL JDBC Transaction (thêm User)
Ở trang **Thêm người dùng**, chọn quyền và gửi biểu mẫu như bình thường để commit. Để kiểm tra rollback, nhập một email chưa dùng, chọn ít nhất một quyền và bật ô **Cố tình gây lỗi khóa ngoại**. DAO sẽ thêm User và các quyền hợp lệ trong transaction, sau đó cố chèn permission ID không tồn tại (`999999`); MySQL báo lỗi FK, DAO gọi `rollback()`. Sau đó kiểm tra:
```sql
SELECT * FROM users WHERE email = 'email_vua_thu@example.com';
SELECT * FROM user_permission WHERE user_id = (SELECT id FROM users WHERE email = 'email_vua_thu@example.com');
```
Kỳ vọng: không có dòng nào được giữ lại. Tắt ô mô phỏng lỗi và gửi lại để kiểm tra commit.
