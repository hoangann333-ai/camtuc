package com.codegym.dao;

import com.codegym.model.User;
import com.codegym.model.Employee;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** JDBC DAO. User row and permission assignments are committed or rolled back together. */
public class UserDAO implements IUserDAO {
    private final String jdbcUrl;
    private final String dbUser;
    private final String dbPassword;

    public UserDAO(String jdbcUrl, String dbUser, String dbPassword) {
        this.jdbcUrl = jdbcUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
    }

    @Override
    public List<User> findUsers(String country, String sortDirection) throws SQLException {
        String direction = "DESC".equalsIgnoreCase(sortDirection) ? "DESC" : "ASC";
        String countryFilter = country == null ? "" : country.trim();
        boolean filter = !countryFilter.isEmpty();
        String sql = "SELECT id, name, email, country FROM users "
                + (filter ? "WHERE country LIKE ? " : "")
                + "ORDER BY name " + direction + ", id ASC";

        List<User> users = new ArrayList<>();
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            if (filter) statement.setString(1, "%" + countryFilter + "%");
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    users.add(new User(result.getInt("id"), result.getString("name"),
                            result.getString("email"), result.getString("country")));
                }
            }
        }
        return users;
    }

    /** Runs the successful transaction variant by default. */
    @Override
    public void insertUpdateUseTransaction() throws SQLException {
        insertUpdateUseTransaction(false);
    }

    /**
     * Recreates the Employee test table, then runs two INSERTs and one UPDATE
     * as one transaction. Set simulateFailure=true to leave UPDATE parameter 1
     * unset and demonstrate that the preceding INSERTs are rolled back.
     */
    @Override
    public void insertUpdateUseTransaction(boolean simulateFailure) throws SQLException {
        try (Connection connection = getConnection(); Statement setup = connection.createStatement()) {
            // These setup statements are intentionally outside the transaction, as in the exercise.
            setup.execute("DROP TABLE IF EXISTS Employee");
            setup.execute("CREATE TABLE Employee ("
                    + "id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, "
                    + "name VARCHAR(100) NOT NULL, "
                    + "salary DECIMAL(10,2) NOT NULL, "
                    + "created_at DATETIME NOT NULL) ENGINE=InnoDB");

            boolean originalAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                String insertSql = "INSERT INTO Employee (name, salary, created_at) VALUES (?, ?, ?)";
                try (PreparedStatement insert = connection.prepareStatement(insertSql)) {
                    insert.setString(1, "Quynh");
                    insert.setBigDecimal(2, new BigDecimal("10.00"));
                    insert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                    insert.executeUpdate();

                    insert.setString(1, "Ngan");
                    insert.setBigDecimal(2, new BigDecimal("20.00"));
                    insert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                    insert.executeUpdate();
                }

                String updateSql = "UPDATE Employee SET salary = ? WHERE name = ?";
                try (PreparedStatement update = connection.prepareStatement(updateSql)) {
                    if (simulateFailure) {
                        // Deliberately bind the wrong index twice: parameter 1 remains unset.
                        update.setBigDecimal(2, new BigDecimal("999.99"));
                        update.setString(2, "Quynh");
                    } else {
                        update.setBigDecimal(1, new BigDecimal("999.99"));
                        update.setString(2, "Quynh");
                    }
                    update.executeUpdate();
                }
                connection.commit();
            } catch (SQLException | RuntimeException failure) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackFailure) {
                    failure.addSuppressed(rollbackFailure);
                }
                throw failure;
            } finally {
                connection.setAutoCommit(originalAutoCommit);
            }
        }
    }

    @Override
    public List<Employee> findEmployees() throws SQLException {
        List<Employee> employees = new ArrayList<>();
        String sql = "SELECT id, name, salary, created_at FROM Employee ORDER BY id";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {
            while (result.next()) {
                employees.add(new Employee(result.getInt("id"), result.getString("name"),
                        result.getBigDecimal("salary"), result.getTimestamp("created_at")));
            }
        }
        return employees;
    }

    @Override
    public void addUserTransaction(User user, int[] permissionIds) throws SQLException {
        addUserTransaction(user, permissionIds, false);
    }

    @Override
    public void addUserTransaction(User user, int[] permissionIds, boolean simulateFailure) throws SQLException {
        try (Connection connection = getConnection()) {
            boolean originalAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            try {
                int userId;
                String insertUserSql = "INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
                try (PreparedStatement userStatement = connection.prepareStatement(
                        insertUserSql, Statement.RETURN_GENERATED_KEYS)) {
                    userStatement.setString(1, user.getName());
                    userStatement.setString(2, user.getEmail());
                    userStatement.setString(3, user.getCountry());
                    if (userStatement.executeUpdate() != 1) {
                        throw new SQLException("Không thể thêm người dùng.");
                    }
                    try (ResultSet keys = userStatement.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("MySQL không trả về ID người dùng mới.");
                        userId = keys.getInt(1);
                    }
                }

                String insertPermissionSql =
                        "INSERT INTO user_permission (user_id, permission_id) VALUES (?, ?)";
                if (permissionIds != null && permissionIds.length > 0) {
                    try (PreparedStatement permissionStatement = connection.prepareStatement(insertPermissionSql)) {
                        for (int permissionId : permissionIds) {
                            permissionStatement.setInt(1, userId);
                            permissionStatement.setInt(2, permissionId);
                            permissionStatement.executeUpdate();
                        }
                    }
                }
                if (simulateFailure) {
                    // Intentional FK violation: permission 999999 is absent from permission table.
                    try (PreparedStatement invalidPermission = connection.prepareStatement(insertPermissionSql)) {
                        invalidPermission.setInt(1, userId);
                        invalidPermission.setInt(2, 999999);
                        invalidPermission.executeUpdate();
                    }
                }
                connection.commit();
            } catch (SQLException | RuntimeException failure) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackFailure) {
                    failure.addSuppressed(rollbackFailure);
                }
                throw failure;
            } finally {
                connection.setAutoCommit(originalAutoCommit);
            }
        }
    }
}
