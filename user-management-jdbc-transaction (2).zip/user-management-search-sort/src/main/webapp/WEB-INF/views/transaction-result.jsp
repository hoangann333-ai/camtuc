<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Kiểm tra JDBC Transaction</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body><main class="container">
  <header class="page-header"><div><p class="eyebrow">JDBC TRANSACTION</p><h1>Kết quả kiểm tra</h1>
  <p class="subtitle">Mode: <c:out value="${mode}"/> — All-or-Nothing</p></div></header>
  <div class="alert ${transactionSuccess ? 'success' : 'error'}"><c:out value="${transactionMessage}"/></div>
  <div class="transaction-links"><a href="${pageContext.request.contextPath}/users?action=test-use-tran&amp;mode=fail">Chạy thử rollback (cố tình gây lỗi)</a>
  <a href="${pageContext.request.contextPath}/users?action=test-use-tran&amp;mode=success">Chạy thử commit (thành công)</a>
  <a href="${pageContext.request.contextPath}/users">Quản lý User</a></div>
  <section class="table-card"><div class="table-heading"><h2>Bảng Employee hiện tại</h2><span><c:out value="${empty employees ? 0 : employees.size()}"/> bản ghi</span></div>
  <div class="table-scroll"><table><thead><tr><th>ID</th><th>Tên</th><th>Lương</th><th>Ngày tạo</th></tr></thead><tbody>
  <c:choose><c:when test="${empty employees}"><tr><td colspan="4" class="empty">Bảng không có bản ghi. Đây là kết quả mong muốn sau rollback.</td></tr></c:when>
  <c:otherwise><c:forEach var="employee" items="${employees}"><tr><td><c:out value="${employee.id}"/></td><td class="name"><c:out value="${employee.name}"/></td><td><c:out value="${employee.salary}"/></td><td><c:out value="${employee.createdAt}"/></td></tr></c:forEach></c:otherwise></c:choose>
  </tbody></table></div></section>
  <p class="note">Thử <code>mode=fail</code>: bảng trống. Thử <code>mode=success</code>: Quynh có lương 999.99 và Ngan có lương 20.00.</p>
</main></body></html>
