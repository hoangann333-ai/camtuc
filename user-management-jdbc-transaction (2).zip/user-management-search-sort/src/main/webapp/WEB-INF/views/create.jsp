<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fn" uri="jakarta.tags.functions" %>
<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Thêm người dùng</title><link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css">
</head>
<body><main class="container narrow">
  <header class="page-header"><div><p class="eyebrow">TRANSACTION DEMO</p><h1>Thêm người dùng</h1>
    <p class="subtitle">Thông tin User và quyền được ghi trong cùng một transaction.</p></div></header>
  <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
  <form class="user-form" method="post" action="${pageContext.request.contextPath}/users">
    <input type="hidden" name="action" value="insertUser">
    <label for="name">Họ tên</label><input id="name" name="name" maxlength="100" required value="<c:out value='${name}'/>" placeholder="Nguyễn Văn A">
    <label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" required value="<c:out value='${email}'/>" placeholder="a@example.com">
    <label for="country">Quốc gia</label><input id="country" name="country" maxlength="100" required value="<c:out value='${country}'/>" placeholder="Vietnam">
    <fieldset><legend>Quyền hạn (có thể chọn nhiều)</legend><div class="permissions">
      <label><input type="checkbox" name="permissions" value="1" ${fn:contains(selectedPermissionIds, '1') ? 'checked' : ''}> Thêm (Add)</label>
      <label><input type="checkbox" name="permissions" value="2" ${fn:contains(selectedPermissionIds, '2') ? 'checked' : ''}> Sửa (Edit)</label>
      <label><input type="checkbox" name="permissions" value="3" ${fn:contains(selectedPermissionIds, '3') ? 'checked' : ''}> Xóa (Delete)</label>
      <label><input type="checkbox" name="permissions" value="4" ${fn:contains(selectedPermissionIds, '4') ? 'checked' : ''}> Xem (View)</label>
    </div></fieldset>
    <label class="simulate-option"><input type="checkbox" name="simulateFailure" value="on" ${simulateFailure ? 'checked' : ''}> Cố tình gây lỗi khóa ngoại để kiểm tra rollback</label>
    <p class="note">Khi bật, ứng dụng sẽ cố gán một quyền không tồn tại. CSDL phải hủy cả User vừa thêm lẫn các quyền đã ghi.</p>
    <div class="form-actions"><button type="submit">Lưu người dùng</button><a class="reset" href="${pageContext.request.contextPath}/users">Quay lại danh sách</a></div>
  </form>
</main></body></html>
